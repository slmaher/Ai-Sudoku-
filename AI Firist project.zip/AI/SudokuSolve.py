import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from queue import Queue, PriorityQueue
import numpy as np
import time

# Initial 2x2 Sudoku board (4x4 grid)
initial_board = [
    [1, 0, 0, 4],
    [0, 0, 0, 0],
    [0, 0, 0, 0],
    [4, 0, 0, 3]
]

# Helper functions
def get_valid_numbers(board, row, col):
    """Find valid numbers for a cell."""
    def in_row(board, row):
        return set(board[row])

    def in_col(board, col):
        return set(board[i][col] for i in range(4))

    def in_square(board, row, col):
        start_row, start_col = 2 * (row // 2), 2 * (col // 2)
        return set(board[r][c] for r in range(start_row, start_row + 2) for c in range(start_col, start_col + 2))

    return set(range(1, 5)) - in_row(board, row) - in_col(board, col) - in_square(board, row, col)


def get_first_unfilled_square(board):
    """Get the first empty cell."""
    for row in range(4):
        for col in range(4):
            if board[row][col] == 0:
                return row, col
    return None, None


# DFS Solver
def dfs_solve(board, frames):
    """Solve using Depth-First Search."""
    row, col = get_first_unfilled_square(board)
    if row is None:
        frames.append(np.array(board))
        return True

    possible_numbers = get_valid_numbers(board, row, col)
    for number in possible_numbers:
        board[row][col] = number
        frames.append(np.array(board))
        if dfs_solve(board, frames):
            return True
        board[row][col] = 0  # Backtrack

    return False


# BFS Solver
def bfs_solve(board):
    """Solve using Breadth-First Search."""
    queue = Queue()
    queue.put((board, []))
    frames = [np.array(board)]

    while not queue.empty():
        current_board, path = queue.get()
        row, col = get_first_unfilled_square(current_board)
        if row is None:
            frames.append(np.array(current_board))
            return current_board, frames

        possible_numbers = get_valid_numbers(current_board, row, col)
        for number in possible_numbers:
            new_board = [row[:] for row in current_board]
            new_board[row][col] = number
            queue.put((new_board, path + [(row, col, number)]))
            frames.append(np.array(new_board))

    return None, frames


# UCS Solver
def ucs_solve(board):
    """Solve using Uniform-Cost Search."""
    pq = PriorityQueue()
    pq.put((0, board, []))
    frames = [np.array(board)]

    while not pq.empty():
        cost, current_board, path = pq.get()
        row, col = get_first_unfilled_square(current_board)
        if row is None:
            frames.append(np.array(current_board))
            return current_board, frames

        possible_numbers = get_valid_numbers(current_board, row, col)
        for number in possible_numbers:
            new_board = [row[:] for row in current_board]
            new_board[row][col] = number
            pq.put((cost + 1, new_board, path + [(row, col, number)]))
            frames.append(np.array(new_board))

    return None, frames


# Visualization
def visualize_solving(frames, title="Sudoku Solving Process"):
    """Visualize the solving process."""
    fig, ax = plt.subplots(figsize=(4, 4))
    ax.set_title(title)
    ax.axis("off")

    def update(frame):
        ax.clear()
        ax.axis("off")
        ax.set_title(title)
        for row in range(4):
            for col in range(4):
                value = frame[row][col]
                if value != 0:
                    color = "black" if initial_board[row][col] != 0 else "blue"
                    ax.text(col, row, str(value), ha="center", va="center", color=color, fontsize=14)
        ax.imshow(np.zeros_like(frame), cmap="Greys", interpolation="none")

    ani = FuncAnimation(fig, update, frames=frames, interval=300, repeat=False)
    plt.show()


# Helper function to time solvers multiple runs
def time_solver(solver, board, iterations=100):
    start_time = time.perf_counter()
    for _ in range(iterations):
        fresh_board = [row[:] for row in board]  # Create a fresh copy of the board
        frames = []  # Initialize a fresh frames list
        solver(fresh_board, frames)
    end_time = time.perf_counter()
    return (end_time - start_time) / iterations


# Main execution
if __name__ == "__main__":
    print("Initial Board:")
    for row in initial_board:
        print(row)

    # DFS
    dfs_frames = [np.array(initial_board)]  # Frames for visualization
    dfs_time = time_solver(lambda b, f: dfs_solve(b, f), initial_board)  # Corrected timing
    dfs_solve([row[:] for row in initial_board], dfs_frames)  # Solve once for visualization
    print("\nDFS Solved Board:")
    for row in dfs_frames[-1]:
        print(row)
    print(f"DFS Time (avg over 100 runs): {dfs_time:.6f}s")
    visualize_solving(dfs_frames, title="DFS Solving Process")

    # BFS
    bfs_board, bfs_frames = bfs_solve([row[:] for row in initial_board])
    bfs_time = time_solver(lambda b, f: bfs_solve(b), initial_board)
    print("\nBFS Solved Board:")
    for row in bfs_board:
        print(row)
    print(f"BFS Time (avg over 100 runs): {bfs_time:.6f}s")
    visualize_solving(bfs_frames, title="BFS Solving Process")

    # UCS
    ucs_board, ucs_frames = ucs_solve([row[:] for row in initial_board])
    ucs_time = time_solver(lambda b, f: ucs_solve(b), initial_board)
    print("\nUCS Solved Board:")
    for row in ucs_board:
        print(row)
    print(f"UCS Time (avg over 100 runs): {ucs_time:.6f}s")
    visualize_solving(ucs_frames, title="UCS Solving Process")
