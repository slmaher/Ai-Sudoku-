# Sudoku

Desktop application developed using Python and TKinter. Users can complete puzzles, generate new ones, and watch the computer solve them automatically with a depth first search backtracking algorithm
